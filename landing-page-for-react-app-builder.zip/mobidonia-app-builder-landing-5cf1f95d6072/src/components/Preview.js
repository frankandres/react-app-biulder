import React, { Component } from 'react'

export default class Preview extends Component {
    render() {
        return (
            <section className="section section-lg">
                <div className="container">
                    <div className="row justify-content-center">
                        <div className="col-md-12">
                            <h1 className="text-center"><strong>Download our Preview App</strong></h1>
                            <h6 className="text-center text-primary">Login with your username and password and preview the apps you make directly on your mobile phone in realtime.</h6>
                            <br/><br/>{
                                (this.props.info.playStore && this.props.info.playStore.length > 5) && (this.props.info.appStore && this.props.info.appStore.length > 5)?
                                    <div className="row row-grid justify-content-center">
                                        <div className="col-md-3 text-center">
                                            <a href={this.props.info.playStore} target="_blank" rel="noopener noreferrer"><img alt="..." className="img-preview" src="./../assets/img/google-en.png" /></a>
                                        </div>
                                        <div className="col-md-3 text-center">
                                            <a href={this.props.info.appStore} target="_blank" rel="noopener noreferrer"><img alt="..." className="img-preview" src="./../assets/img/apple-en.png" /></a>
                                        </div>
                                    </div>
                                    :
                                    this.props.info.playStore && this.props.info.playStore.length > 5 ?
                                    <div className="row row-grid justify-content-center">
                                        <div className="col-md-4 text-center">
                                            <a href={this.props.info.playStore} target="_blank" rel="noopener noreferrer"><img alt="..." className="img-preview" src="./../assets/img/google-en.png" /></a>
                                        </div>
                                    </div>
                                    :
                                    <div className="row row-grid justify-content-center">
                                        <div className="col-md-4 text-center">
                                            <a href={this.props.info.appStore} target="_blank" rel="noopener noreferrer"><img alt="..." className="img-preview" src="./../assets/img/apple-en.png" /></a>
                                        </div>
                                    </div>
                                }
                        </div>
                    </div>
                </div>
            </section>
        )
    }
}
