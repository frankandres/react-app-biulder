import firebaseConfig from './firebase_config'
var defaultExport={}

defaultExport.firebaseConfig = firebaseConfig.config;

export default defaultExport;