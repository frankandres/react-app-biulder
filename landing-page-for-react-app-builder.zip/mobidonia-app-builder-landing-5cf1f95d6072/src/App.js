/* eslint-disable */
import React, { Component } from 'react'
import * as firebase from 'firebase'
import Navigation from './components/Navigation'
import HeaderMain from './components/HeaderMain'
import Footer from './components/Footer'
import Payment from './components/Payment'
import Features from './components/Features'
import Preview from './components/Preview'
import Config from './config/app'
import ReactGA from 'react-ga'

import { css } from '@emotion/core';
// First way to import
//import { ClipLoader } from 'react-spinners';
// Another way to import. This is recommended to reduce bundle size
import RingLoader from 'react-spinners/RingLoader';
 
// Can be a string as well. Need to ensure each key-value pair ends with ;
const override = css`
    display: block;
    margin: 0 auto;
    border-color: #e14eca;
`;

class App extends Component {

  constructor(props){
    super(props);

    if (!firebase.apps.length) {
      firebase.initializeApp(Config.firebaseConfig);
    }
    
    this.state = {
      info: {},
      types: null,
      plans: {},
      loading: true
    }

    this.getInfo = this.getInfo.bind(this);  
  }

  componentDidMount(){
    var _this = this;
    this.getInfo(); 
    setTimeout(function(){
      _this.setState({
        loading: false
      })
    }, 2000);
  }

  checkGAUniquedID(id){
    if(id){
      var idValidation = /(UA|YT|MO)-\d+-\d+/i.test(id);
      if(idValidation){
        //ReactGA.initialize('UA-102630608-4'); // Here we should use our GA id
        ReactGA.initialize(id);
        ReactGA.pageview("/");
    
        console.log("Google Analytics Unique ID initialized!");
      }else console.log("Google Analytics Unique ID initialized is wrong!");
    }else{
      console.log("You don't have setup your Google Analytics Unique ID!");
    }
  }

  getInfo(){
    var _this = this;
    firebase.database().ref('/rab_saas_site').on('value', function (snapshot) {
        _this.setState({
          info: snapshot.val(),
          plans: snapshot.val().pricing.plans,
        },()=>{
          if(snapshot.val().GAUniqueID){
            _this.checkGAUniquedID(snapshot.val().GAUniqueID)
          }
        }) 
    });   
  }
  render() {
    if(!this.state.loading){
      return (
        <div>
          <Navigation
            info={this.state.info}
            />
          <div className="wrapper">
            <HeaderMain info={this.state.info} />
            <Features features={this.state.info.features||[]} />
            <Payment info={this.state.info} plans={this.state.plans||[]} pricing={this.state.info.pricing||[]} />{
              (this.state.info.preview_app && this.state.info.preview_app.playStore && this.state.info.preview_app.playStore.length > 5) 
                || (this.state.info.preview_app && this.state.info.preview_app.appStore && this.state.info.preview_app.appStore.length > 5) 
                ? 
                <Preview info={this.state.info.preview_app || [] } /> 
                :
                <div></div>
            }
          </div>
          <Footer info={this.state.info} />
        </div>
      );
    }else if(this.state.loading){
      return (
        <div className='sweet-loading' style={{'paddingTop':'250px'}}>
          <RingLoader
            css={override}
            sizeUnit={"px"}
            size={150}
            color={'#e14eca'}
            loading={this.state.loading}
          />
      </div> 
      )
    }
  }
}

export default App;
