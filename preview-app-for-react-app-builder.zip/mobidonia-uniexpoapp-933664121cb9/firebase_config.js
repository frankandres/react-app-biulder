var firebaseConfig={
    apiKey: "AIzaSyDicBiK1ll7R2F1l1tc6-aEJyJkNqx-C6k",
    authDomain: "appbuilderonline.firebaseapp.com",
    databaseURL: "https://appbuilderonline.firebaseio.com",
    projectId: "appbuilderonline",
    storageBucket: "appbuilderonline.appspot.com",
    messagingSenderId: "570779541112",
    appId: "1:570779541112:web:48a702e126c1e7f028578d"
};
exports.config=firebaseConfig;